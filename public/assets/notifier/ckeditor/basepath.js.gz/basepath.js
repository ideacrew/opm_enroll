
var CKEDITOR_BASEPATH = '/assets/notifier/ckeditor/';
